# pipe > 2025-04-16 8:13pm
https://universe.roboflow.com/nanoka/pipe-jdlje

Provided by a Roboflow user
License: CC BY 4.0

